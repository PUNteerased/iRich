"""Experience replay buffer for weekly incremental training."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class ExperienceBuffer:
    def __init__(self, directory: Path | str) -> None:
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)

    def append(self, symbol: str, record: dict[str, Any]) -> Path:
        record = dict(record)
        record.setdefault("symbol", symbol)
        record.setdefault("ts", datetime.now(timezone.utc).isoformat())
        day = datetime.now(timezone.utc).strftime("%Y%m%d")
        path = self.directory / f"{symbol.lower()}_{day}.jsonl"
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, default=str) + "\n")
        return path

    def load_all(self, symbol: str | None = None) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        pattern = f"{symbol.lower()}_*.jsonl" if symbol else "*.jsonl"
        for path in sorted(self.directory.glob(pattern)):
            with open(path, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        rows.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
        return rows
