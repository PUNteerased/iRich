"""Risk guards for $100 micro account: fixed lot, max $2 risk, monthly halt."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

import MetaTrader5 as mt5


@dataclass
class RiskDecision:
    ok: bool
    volume: float
    risk_usd: float
    sl: float
    tp: float
    reason: str = ""


class MonthlyCircuitBreaker:
    def __init__(self, max_dd_pct: float = 10.0) -> None:
        self.max_dd_pct = max_dd_pct
        self._month: str | None = None
        self._start_equity: float | None = None
        self.halted = False

    def update(self, equity: float, now: datetime | None = None) -> bool:
        now = now or datetime.now(timezone.utc)
        key = f"{now.year:04d}-{now.month:02d}"
        if self._month != key:
            self._month = key
            self._start_equity = equity
            self.halted = False
        if self._start_equity and self._start_equity > 0:
            dd_pct = (equity - self._start_equity) / self._start_equity * 100.0
            if dd_pct <= -abs(self.max_dd_pct):
                self.halted = True
        return self.halted


def pip_size(symbol_info: Any) -> float:
    """Approximate pip/point size from digits."""
    digits = int(symbol_info.digits)
    point = float(symbol_info.point)
    if digits in (3, 5):
        return point * 10
    return point


def calc_risk_usd(symbol: str, volume: float, entry: float, sl: float) -> float | None:
    info = mt5.symbol_info(symbol)
    if info is None:
        return None
    tick = mt5.symbol_info_tick(symbol)
    if tick is None:
        return None

    tick_size = float(info.trade_tick_size) or float(info.point)
    tick_value = float(info.trade_tick_value)
    if tick_size <= 0 or tick_value <= 0:
        return None
    distance = abs(entry - sl)
    ticks = distance / tick_size
    return ticks * tick_value * volume


def clamp_sl_to_caps(
    symbol: str,
    entry: float,
    sl: float,
    side: str,
    caps: dict[str, Any],
) -> float:
    """Clamp SL distance into configured pip/point/dollar caps when possible."""
    info = mt5.symbol_info(symbol)
    if info is None:
        return sl
    point = float(info.point)
    sym_caps = caps.get(symbol, {})
    dist = abs(entry - sl)

    if symbol == "BTCUSD":
        min_d = float(sym_caps.get("min_dollars", 100))
        max_d = float(sym_caps.get("max_dollars", 200))
        dist = min(max(dist, min_d), max_d)
    elif symbol == "XAUUSD":
        min_pts = float(sym_caps.get("min_points", 150)) * point
        max_pts = float(sym_caps.get("max_points", 250)) * point
        dist = min(max(dist, min_pts), max_pts)
    else:
        pip = pip_size(info)
        min_p = float(sym_caps.get("min_pips", 10)) * pip
        max_p = float(sym_caps.get("max_pips", 15)) * pip
        dist = min(max(dist, min_p), max_p)

    if side.upper() in ("BUY", "BULLISH"):
        return entry - dist
    return entry + dist


def is_spread_ok(symbol: str, max_spread_price: float | None) -> tuple[bool, float]:
    """
    Return (ok, spread_in_price).
    If max_spread_price is None, always ok.
    """
    info = mt5.symbol_info(symbol)
    tick = mt5.symbol_info_tick(symbol)
    if info is None or tick is None:
        return False, 0.0
    spread_price = abs(float(tick.ask) - float(tick.bid))
    if max_spread_price is None:
        return True, spread_price
    return spread_price <= max_spread_price, spread_price


def build_trade_levels(
    symbol: str,
    side: str,
    entry: float,
    raw_sl: float,
    rr: float,
    volume: float,
    max_risk_usd: float,
    sl_caps: dict[str, Any],
) -> RiskDecision:
    sl = clamp_sl_to_caps(symbol, entry, raw_sl, side, sl_caps)
    dist = abs(entry - sl)
    if dist <= 0:
        return RiskDecision(False, volume, 0.0, sl, entry, "invalid_sl_distance")

    if side.upper() in ("BUY", "BULLISH"):
        tp = entry + dist * rr
    else:
        tp = entry - dist * rr

    risk = calc_risk_usd(symbol, volume, entry, sl)
    if risk is None:
        return RiskDecision(False, volume, 0.0, sl, tp, "risk_calc_failed")
    if risk > max_risk_usd:
        return RiskDecision(False, volume, risk, sl, tp, f"risk_${risk:.2f}_gt_max_${max_risk_usd:.2f}")

    info = mt5.symbol_info(symbol)
    digits = int(info.digits) if info else 5
    return RiskDecision(
        True,
        volume,
        risk,
        round(sl, digits),
        round(tp, digits),
        "ok",
    )


def manage_open_position(
    position: Any,
    atr: float,
    break_even_r: float = 1.0,
    trailing_start_r: float = 1.5,
    trailing_atr_mult: float = 1.0,
) -> dict[str, Any] | None:
    """Return modify request dict for BE / trailing, or None."""
    tick = mt5.symbol_info_tick(position.symbol)
    info = mt5.symbol_info(position.symbol)
    if tick is None or info is None:
        return None

    entry = float(position.price_open)
    sl = float(position.sl) if position.sl else 0.0
    tp = float(position.tp) if position.tp else 0.0
    if sl == 0:
        return None

    sl_dist = abs(entry - sl)
    if sl_dist <= 0:
        return None

    is_buy = position.type == mt5.POSITION_TYPE_BUY
    price = float(tick.bid if is_buy else tick.ask)
    favor = (price - entry) if is_buy else (entry - price)
    digits = int(info.digits)
    new_sl = sl

    if favor >= break_even_r * sl_dist:
        be = entry
        if is_buy and (sl < be):
            new_sl = be
        if not is_buy and (sl == 0 or sl > be):
            new_sl = be

    if favor >= trailing_start_r * sl_dist and atr > 0:
        trail = atr * trailing_atr_mult
        if is_buy:
            candidate = price - trail
            if candidate > new_sl:
                new_sl = candidate
        else:
            candidate = price + trail
            if new_sl == 0 or candidate < new_sl:
                new_sl = candidate

    new_sl = round(new_sl, digits)
    if new_sl == round(sl, digits):
        return None

    return {
        "action": mt5.TRADE_ACTION_SLTP,
        "position": position.ticket,
        "symbol": position.symbol,
        "sl": new_sl,
        "tp": tp,
    }
