"""Hybrid signal fusion gates for sniper entries."""

from __future__ import annotations

from dataclasses import dataclass

from .learning.confidence import ConfidenceStore
from .news.sentiment import SentimentEngine


@dataclass
class FusionDecision:
    signal: str  # BUY | SELL | WAIT
    score: float
    reason: str


def fuse_signal(
    symbol: str,
    side: str,
    model_prob: float,
    min_prob: float,
    news_blocked: bool,
    news_block_reason: str,
    monthly_halted: bool,
    has_open_position: bool,
    mtf_aligned: bool,
    mtf_reasons: list[str],
    usd_sentiment: float,
    confidence: ConfidenceStore,
    tech_weight: float = 0.6,
    news_weight: float = 0.4,
    sentiment_engine: SentimentEngine | None = None,
) -> FusionDecision:
    if monthly_halted:
        return FusionDecision("WAIT", 0.0, "monthly_circuit_breaker")
    if has_open_position:
        return FusionDecision("WAIT", 0.0, "max_open_positions")
    if news_blocked:
        return FusionDecision("WAIT", 0.0, f"news_block:{news_block_reason}")
    if not mtf_aligned:
        return FusionDecision("WAIT", 0.0, "mtf:" + ",".join(mtf_reasons or ["misaligned"]))

    thr = confidence.effective_min_prob(min_prob, symbol)
    if model_prob < thr:
        return FusionDecision("WAIT", model_prob, f"prob_{model_prob:.3f}_lt_{thr:.3f}")

    # technical signed confidence in [-1,1]
    tech = model_prob if side == "BUY" else -model_prob
    engine = sentiment_engine or SentimentEngine()
    news_bias = engine.map_to_symbol_bias(symbol, usd_sentiment)
    final = tech_weight * tech + news_weight * news_bias

    # News must not strongly contradict
    if side == "BUY" and news_bias < -0.55:
        return FusionDecision("WAIT", final, "news_contradict_buy")
    if side == "SELL" and news_bias > 0.55:
        return FusionDecision("WAIT", final, "news_contradict_sell")

    if side == "BUY" and final <= 0:
        return FusionDecision("WAIT", final, "fusion_score_non_positive")
    if side == "SELL" and final >= 0:
        return FusionDecision("WAIT", final, "fusion_score_non_negative")

    return FusionDecision(side, final, "ok")
