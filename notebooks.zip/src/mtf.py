"""Multi-timeframe alignment: H1 → M15 → M5 → M1."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import pandas as pd

from .features import build_features
from .smc import (
    Bias,
    StructureSignal,
    detect_choch,
    detect_fvg_entry,
    detect_liquidity_sweep,
    detect_order_block,
)


@dataclass
class MTFResult:
    bias: Bias
    sweep: StructureSignal
    choch: StructureSignal
    fvg: StructureSignal
    aligned: bool
    entry: float | None = None
    sl: float | None = None
    reasons: list[str] = field(default_factory=list)


def get_h1_bias(df_h1: pd.DataFrame, ema_len: int = 200) -> Bias:
    """H1 macro bias from completed bar vs EMA200."""
    if len(df_h1) < ema_len + 5:
        return "NEUTRAL"
    feat, _ = build_features(df_h1)
    # use last completed bar
    row = feat.iloc[-2] if len(feat) >= 2 else feat.iloc[-1]
    close = float(row["close"])
    ema = float(row["ema_200"])
    if not pd.notna(ema):
        return "NEUTRAL"
    ob = detect_order_block(df_h1, "BULLISH" if close > ema else "BEARISH")
    if close > ema:
        # optional OB agreement soft — bias still bullish above EMA
        return "BULLISH"
    if close < ema:
        return "BEARISH"
    return "NEUTRAL"


def evaluate_mtf(
    df_h1: pd.DataFrame,
    df_m15: pd.DataFrame,
    df_m5: pd.DataFrame,
    df_m1: pd.DataFrame,
    atr_sl_mult: float = 1.0,
    require_full: bool = True,
) -> MTFResult:
    bias = get_h1_bias(df_h1)
    reasons: list[str] = []
    if bias == "NEUTRAL":
        return MTFResult(
            bias=bias,
            sweep=StructureSignal(False, reason="neutral_bias"),
            choch=StructureSignal(False, reason="neutral_bias"),
            fvg=StructureSignal(False, reason="neutral_bias"),
            aligned=False,
            reasons=["h1_neutral"],
        )

    sweep = detect_liquidity_sweep(df_m15, bias)
    choch = detect_choch(df_m5, bias)

    m1_feat, _ = build_features(df_m1)
    completed = m1_feat.iloc[-2] if len(m1_feat) >= 2 else m1_feat.iloc[-1]
    atr = float(completed["atr_14"]) if pd.notna(completed["atr_14"]) else None
    fvg = detect_fvg_entry(df_m1, bias, atr=atr, atr_sl_mult=atr_sl_mult)

    if not sweep.ok:
        reasons.append(sweep.reason or "sweep_fail")
    if not choch.ok:
        reasons.append(choch.reason or "choch_fail")
    if not fvg.ok:
        reasons.append(fvg.reason or "fvg_fail")

    aligned = sweep.ok and choch.ok and fvg.ok if require_full else fvg.ok and bias != "NEUTRAL"
    entry = float(completed["close"]) if aligned else None
    sl = fvg.sl if aligned else None

    return MTFResult(
        bias=bias,
        sweep=sweep,
        choch=choch,
        fvg=fvg,
        aligned=aligned,
        entry=entry,
        sl=sl,
        reasons=reasons,
    )


def rates_to_df(rates: Any) -> pd.DataFrame:
    df = pd.DataFrame(rates)
    if df.empty:
        return df
    if "time" in df.columns:
        df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
    return df
