"""Load config.yaml and optional .env overrides."""

from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]


def _deep_get(d: dict, *keys: str, default: Any = None) -> Any:
    cur: Any = d
    for k in keys:
        if not isinstance(cur, dict) or k not in cur:
            return default
        cur = cur[k]
    return cur


class Config:
    def __init__(self, path: Path | str | None = None) -> None:
        load_dotenv(ROOT / ".env")
        cfg_path = Path(path) if path else ROOT / "config.yaml"
        with open(cfg_path, encoding="utf-8") as f:
            self._raw: dict[str, Any] = yaml.safe_load(f) or {}

        self.mode = str(self._raw.get("mode", "demo")).lower()
        if self.mode != "demo" and os.getenv("ALLOW_LIVE", "0") != "1":
            raise RuntimeError(
                "Live mode blocked. Keep mode: demo or set ALLOW_LIVE=1 after Demo validation."
            )

        # MT5 credentials from env override yaml nulls
        mt5 = self._raw.setdefault("mt5", {})
        mt5["login"] = _env_int("MT5_LOGIN", mt5.get("login"))
        mt5["password"] = os.getenv("MT5_PASSWORD") or mt5.get("password")
        mt5["server"] = os.getenv("MT5_SERVER") or mt5.get("server")
        mt5["path"] = os.getenv("MT5_PATH") or mt5.get("path")

    @property
    def raw(self) -> dict[str, Any]:
        return self._raw

    def get(self, *keys: str, default: Any = None) -> Any:
        return _deep_get(self._raw, *keys, default=default)

    @property
    def symbols(self) -> list[str]:
        return list(self._raw.get("symbols", []))

    @property
    def weekday_symbols(self) -> list[str]:
        return list(
            self._raw.get(
                "weekday_symbols",
                [s for s in self.symbols if s.upper() != "BTCUSD"],
            )
        )

    @property
    def weekend_symbols(self) -> list[str]:
        return list(self._raw.get("weekend_symbols", ["BTCUSD"]))

    def active_symbols(self, now: datetime | None = None) -> list[str]:
        """Mon–Fri = FX/Gold, Sat–Sun = BTCUSD (local time)."""
        now = now or datetime.now()
        if now.weekday() >= 5:  # 5=Sat, 6=Sun
            return list(self.weekend_symbols)
        return list(self.weekday_symbols)

    def atr_sl_mult(self, symbol: str) -> float:
        by_sym = self.get("risk", "atr_sl_mult_by_symbol", default={}) or {}
        if symbol in by_sym:
            return float(by_sym[symbol])
        return float(self.get("risk", "atr_sl_mult", default=1.0))

    def max_spread(self, symbol: str) -> float | None:
        caps = self.get("spread", "max_by_symbol", default={}) or {}
        if symbol not in caps:
            return None
        return float(caps[symbol])

    def order_deviation(self, symbol: str) -> int:
        by_sym = self.get("mt5", "deviation_by_symbol", default={}) or {}
        if symbol in by_sym:
            return int(by_sym[symbol])
        return int(self.get("mt5", "deviation", default=20))

    @property
    def magic(self) -> int:
        return int(self._raw.get("magic", 999100))

    @property
    def lot_volume(self) -> float:
        return float(self.get("lot", "volume", default=0.01))

    @property
    def max_risk_usd(self) -> float:
        return float(self.get("risk", "max_risk_usd", default=2.0))

    @property
    def rr(self) -> float:
        return float(self.get("risk", "rr", default=3.0))

    @property
    def min_probability(self) -> float:
        return float(self.get("sniper", "min_probability", default=0.75))

    @property
    def scan_seconds(self) -> int:
        return int(self.get("sniper", "scan_seconds", default=10))

    def model_path(self, symbol: str) -> Path:
        models_dir = ROOT / self.get("paths", "models", default="models")
        return models_dir / f"{symbol.lower()}_sniper.pkl"

    def resolve_path(self, *keys: str) -> Path:
        rel = self.get(*keys, default="")
        p = Path(rel)
        return p if p.is_absolute() else ROOT / p


def _env_int(name: str, fallback: Any) -> int | None:
    val = os.getenv(name)
    if val is None or val == "":
        return int(fallback) if fallback not in (None, "") else None
    return int(val)


def load_config(path: Path | str | None = None) -> Config:
    return Config(path)
