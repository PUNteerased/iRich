"""Smart Money Concepts: liquidity sweep, ChoCH, FVG, order blocks."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

import numpy as np
import pandas as pd

Bias = Literal["BULLISH", "BEARISH", "NEUTRAL"]


@dataclass
class StructureSignal:
    ok: bool
    side: Bias = "NEUTRAL"
    level: float | None = None
    sl: float | None = None
    reason: str = ""


def _swing_highs_lows(
    df: pd.DataFrame, left: int = 3, right: int = 3
) -> tuple[pd.Series, pd.Series]:
    high = df["high"]
    low = df["low"]
    sh = pd.Series(False, index=df.index)
    sl = pd.Series(False, index=df.index)
    for i in range(left, len(df) - right):
        window_h = high.iloc[i - left : i + right + 1]
        window_l = low.iloc[i - left : i + right + 1]
        if high.iloc[i] == window_h.max():
            sh.iloc[i] = True
        if low.iloc[i] == window_l.min():
            sl.iloc[i] = True
    return sh, sl


def detect_liquidity_sweep(
    df: pd.DataFrame, bias: Bias, lookback: int = 50, swing: int = 3
) -> StructureSignal:
    """Completed-bar liquidity sweep aligned with H1 bias."""
    if len(df) < lookback + swing * 2 + 5:
        return StructureSignal(False, reason="insufficient_bars")

    work = df.iloc[:-1].copy()  # drop forming bar
    sh, sl = _swing_highs_lows(work, left=swing, right=swing)
    i = len(work) - 1
    row = work.iloc[i]

    prior = work.iloc[max(0, i - lookback) : i]
    prior_sh = prior.loc[sh.loc[prior.index]]
    prior_sl = prior.loc[sl.loc[prior.index]]

    if bias == "BULLISH" and not prior_sl.empty:
        lvl = float(prior_sl["low"].iloc[-1])
        swept = float(row["low"]) < lvl and float(row["close"]) > lvl
        if swept:
            return StructureSignal(True, "BULLISH", lvl, float(row["low"]), "m15_sweep_low")
    if bias == "BEARISH" and not prior_sh.empty:
        lvl = float(prior_sh["high"].iloc[-1])
        swept = float(row["high"]) > lvl and float(row["close"]) < lvl
        if swept:
            return StructureSignal(True, "BEARISH", lvl, float(row["high"]), "m15_sweep_high")
    return StructureSignal(False, bias, reason="no_sweep")


def detect_choch(
    df: pd.DataFrame, bias: Bias, lookback: int = 40, swing: int = 2
) -> StructureSignal:
    """Change of Character on completed M5 bars."""
    if len(df) < lookback + 10:
        return StructureSignal(False, reason="insufficient_bars")

    work = df.iloc[:-1].copy()
    sh, sl = _swing_highs_lows(work, left=swing, right=swing)
    i = len(work) - 1
    close = float(work["close"].iloc[i])

    prior = work.iloc[max(0, i - lookback) : i]
    prior_sh = prior.loc[sh.loc[prior.index]]
    prior_sl = prior.loc[sl.loc[prior.index]]

    if bias == "BULLISH" and not prior_sh.empty:
        lvl = float(prior_sh["high"].iloc[-1])
        if close > lvl:
            return StructureSignal(True, "BULLISH", lvl, reason="m5_choch_bull")
    if bias == "BEARISH" and not prior_sl.empty:
        lvl = float(prior_sl["low"].iloc[-1])
        if close < lvl:
            return StructureSignal(True, "BEARISH", lvl, reason="m5_choch_bear")
    return StructureSignal(False, bias, reason="no_choch")


def _last_fvg(work: pd.DataFrame, bullish: bool) -> tuple[float, float, float] | None:
    """Return (top, bottom, mid) of latest FVG or None."""
    for i in range(len(work) - 1, 2, -1):
        c0 = work.iloc[i - 2]
        c2 = work.iloc[i]
        if bullish and float(c2["low"]) > float(c0["high"]):
            top = float(c2["low"])
            bottom = float(c0["high"])
            return top, bottom, (top + bottom) / 2.0
        if not bullish and float(c2["high"]) < float(c0["low"]):
            top = float(c0["low"])
            bottom = float(c2["high"])
            return top, bottom, (top + bottom) / 2.0
    return None


def detect_fvg_entry(
    df: pd.DataFrame, bias: Bias, atr: float | None = None, atr_sl_mult: float = 1.0
) -> StructureSignal:
    """M1 FVG touch entry on completed bars; SL beyond FVG extreme or ATR."""
    if len(df) < 20:
        return StructureSignal(False, reason="insufficient_bars")

    work = df.iloc[:-1].copy()
    price = float(work["close"].iloc[-1])
    bullish = bias == "BULLISH"
    fvg = _last_fvg(work, bullish=bullish)
    if fvg is None:
        return StructureSignal(False, bias, reason="no_fvg")

    top, bottom, mid = fvg
    in_zone = bottom <= price <= top
    # also allow wick touch on last completed bar
    last = work.iloc[-1]
    touched = float(last["low"]) <= top and float(last["high"]) >= bottom
    if not (in_zone or touched):
        return StructureSignal(False, bias, mid, reason="price_not_in_fvg")

    if bullish:
        structural_sl = bottom
        if atr is not None:
            structural_sl = min(structural_sl, price - atr * atr_sl_mult)
        return StructureSignal(True, "BULLISH", mid, structural_sl, "m1_fvg_bull")
    structural_sl = top
    if atr is not None:
        structural_sl = max(structural_sl, price + atr * atr_sl_mult)
    return StructureSignal(True, "BEARISH", mid, structural_sl, "m1_fvg_bear")


def detect_order_block(df: pd.DataFrame, bias: Bias, lookback: int = 30) -> StructureSignal:
    """Simple OB: last opposite candle before impulsive move."""
    if len(df) < lookback + 5:
        return StructureSignal(False, reason="insufficient_bars")
    work = df.iloc[:-1].tail(lookback)
    if bias == "BULLISH":
        # last bearish candle followed by strong bullish displacement
        for i in range(len(work) - 3, 1, -1):
            c = work.iloc[i]
            n1 = work.iloc[i + 1]
            if float(c["close"]) < float(c["open"]) and float(n1["close"]) > float(n1["open"]):
                if float(n1["close"]) > float(c["high"]):
                    return StructureSignal(
                        True,
                        "BULLISH",
                        float(c["low"]),
                        float(c["low"]),
                        "ob_bull",
                    )
    if bias == "BEARISH":
        for i in range(len(work) - 3, 1, -1):
            c = work.iloc[i]
            n1 = work.iloc[i + 1]
            if float(c["close"]) > float(c["open"]) and float(n1["close"]) < float(n1["open"]):
                if float(n1["close"]) < float(c["low"]):
                    return StructureSignal(
                        True,
                        "BEARISH",
                        float(c["high"]),
                        float(c["high"]),
                        "ob_bear",
                    )
    return StructureSignal(False, bias, reason="no_ob")


def smc_feature_frame(df: pd.DataFrame, prefix: str = "") -> pd.DataFrame:
    """Attach lightweight SMC numeric features for ML."""
    out = df.copy()
    p = f"{prefix}_" if prefix else ""
    work = out.iloc[:-1] if len(out) else out
    atr = (out["high"] - out["low"]).rolling(14).mean()

    sweep_bull = np.zeros(len(out))
    sweep_bear = np.zeros(len(out))
    choch_bull = np.zeros(len(out))
    choch_bear = np.zeros(len(out))
    fvg_bull_dist = np.full(len(out), np.nan)
    fvg_bear_dist = np.full(len(out), np.nan)

    sh, sl = _swing_highs_lows(out)

    for i in range(20, len(out) - 1):
        close = float(out["close"].iloc[i])
        # sweep approx vs prior swing
        prior_sl = out["low"].iloc[max(0, i - 40) : i][sl.iloc[max(0, i - 40) : i]]
        prior_sh = out["high"].iloc[max(0, i - 40) : i][sh.iloc[max(0, i - 40) : i]]
        if len(prior_sl):
            lvl = float(prior_sl.iloc[-1])
            if float(out["low"].iloc[i]) < lvl <= float(out["close"].iloc[i]):
                sweep_bull[i] = 1.0
        if len(prior_sh):
            lvl = float(prior_sh.iloc[-1])
            if float(out["high"].iloc[i]) > lvl >= float(out["close"].iloc[i]):
                sweep_bear[i] = 1.0
        if len(prior_sh) and close > float(prior_sh.iloc[-1]):
            choch_bull[i] = 1.0
        if len(prior_sl) and close < float(prior_sl.iloc[-1]):
            choch_bear[i] = 1.0

        bull_fvg = _last_fvg(out.iloc[: i + 1], True)
        bear_fvg = _last_fvg(out.iloc[: i + 1], False)
        if bull_fvg:
            fvg_bull_dist[i] = (close - bull_fvg[2]) / (atr.iloc[i] or np.nan)
        if bear_fvg:
            fvg_bear_dist[i] = (bear_fvg[2] - close) / (atr.iloc[i] or np.nan)

    out[f"{p}sweep_bull"] = sweep_bull
    out[f"{p}sweep_bear"] = sweep_bear
    out[f"{p}choch_bull"] = choch_bull
    out[f"{p}choch_bear"] = choch_bear
    out[f"{p}fvg_bull_dist"] = fvg_bull_dist
    out[f"{p}fvg_bear_dist"] = fvg_bear_dist
    return out


SMC_FEATURE_COLS = [
    "sweep_bull",
    "sweep_bear",
    "choch_bull",
    "choch_bear",
    "fvg_bull_dist",
    "fvg_bear_dist",
]
