"""24/7 Multi-Pair Sniper bot for $100 FBS Demo (FX weekdays + BTCUSD weekends)."""

from __future__ import annotations

import logging
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.config import load_config
from src.features import build_features
from src.fusion import fuse_signal
from src.learning.confidence import ConfidenceStore
from src.learning.replay import ExperienceBuffer
from src.model_runner import ModelRunner, build_live_feature_row
from src.mt5_connector import MT5Connector
from src.news.forexfactory import ForexFactoryCalendar, is_high_impact_near
from src.news.sentiment import SentimentEngine
from src.risk import MonthlyCircuitBreaker, build_trade_levels, is_spread_ok, manage_open_position
from src.sniper import build_sniper_candidate

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("sniper.main")


def manage_positions(mt5c: MT5Connector, cfg, confidence: ConfidenceStore) -> None:
    positions = mt5c.positions(magic_only=True)
    for pos in positions:
        rates = mt5c.copy_rates(pos.symbol, "M1", 50)
        if rates.empty:
            continue
        feat, _ = build_features(rates)
        row = feat.iloc[-2] if len(feat) >= 2 else feat.iloc[-1]
        atr = float(row["atr_14"]) if row.get("atr_14") == row.get("atr_14") else 0.0
        req = manage_open_position(
            pos,
            atr=atr,
            break_even_r=float(cfg.get("risk", "break_even_r", default=1.0)),
            trailing_start_r=float(cfg.get("risk", "trailing_start_r", default=1.5)),
            trailing_atr_mult=float(cfg.get("risk", "trailing_atr_mult", default=1.0)),
        )
        if req:
            mt5c.modify_sltp(req)
            logger.info("Modified SL for %s ticket=%s -> %s", pos.symbol, pos.ticket, req["sl"])


def _record_experience(experience, symbol, decision, candidate, levels, feat_row, bundle, ticket):
    experience.append(
        symbol,
        {
            "side": decision.signal,
            "entry": candidate.entry,
            "sl": levels.sl,
            "tp": levels.tp,
            "prob": candidate.confidence,
            "fusion_score": decision.score,
            "features": feat_row[bundle.feature_cols].to_dict(),
            "ticket": ticket,
        },
    )


def scan_symbol(
    symbol: str,
    mt5c: MT5Connector,
    runner: ModelRunner,
    cfg,
    calendar: ForexFactoryCalendar,
    sentiment: SentimentEngine,
    confidence: ConfidenceStore,
    breaker: MonthlyCircuitBreaker,
    experience: ExperienceBuffer,
) -> bool:
    """Return True if an order was sent."""
    bundle = runner.get(symbol)
    if bundle is None:
        logger.warning("[%s] no model — skip", symbol)
        return False

    max_spread = cfg.max_spread(symbol)
    ok_spread, spread_px = is_spread_ok(symbol, max_spread)
    if not ok_spread:
        logger.info(
            "[%s] spread too high: $%.2f (max $%.2f) — SKIP",
            symbol,
            spread_px,
            max_spread if max_spread is not None else 0.0,
        )
        return False

    df_h1 = mt5c.copy_rates(symbol, "H1", 250)
    df_m15 = mt5c.copy_rates(symbol, "M15", 200)
    df_m5 = mt5c.copy_rates(symbol, "M5", 200)
    df_m1 = mt5c.copy_rates(symbol, "M1", 300)
    if any(df.empty for df in (df_h1, df_m15, df_m5, df_m1)):
        logger.warning("[%s] incomplete rates", symbol)
        return False

    try:
        feat_row, _ = build_live_feature_row(df_h1, df_m15, df_m5, df_m1)
        if bundle.feature_cols:
            missing = [c for c in bundle.feature_cols if c not in feat_row.index]
            if missing:
                logger.warning("[%s] missing features: %s", symbol, missing[:5])
                return False
            probs = bundle.predict_proba_row(feat_row)
        else:
            logger.warning("[%s] model has no feature_cols", symbol)
            return False
    except Exception as exc:  # noqa: BLE001
        logger.exception("[%s] feature/predict failed: %s", symbol, exc)
        return False

    candidate = build_sniper_candidate(
        df_h1,
        df_m15,
        df_m5,
        df_m1,
        probs,
        require_full_mtf=bool(cfg.get("sniper", "require_full_mtf", default=True)),
        atr_sl_mult=cfg.atr_sl_mult(symbol),
        atr_zscore_max=float(cfg.get("sniper", "atr_zscore_max", default=2.0)),
    )

    if candidate.signal not in ("BUY", "SELL"):
        logger.info(
            "[%s] WAIT bias=%s prob=%.3f sniper=%s mtf=%s",
            symbol,
            candidate.bias,
            candidate.confidence,
            candidate.reason,
            ",".join(candidate.mtf.reasons),
        )
        return False

    skip_cal = {
        s.upper()
        for s in (cfg.get("news", "skip_calendar_symbols", default=[]) or [])
    }
    if symbol.upper() in skip_cal:
        news_blocked, news_reason = False, ""
    else:
        news_blocked, news_reason = is_high_impact_near(
            calendar,
            cfg.get("news", "currencies", default=["USD", "EUR", "JPY"]),
            pre_minutes=int(cfg.get("news", "pre_minutes", default=30)),
            post_minutes=int(cfg.get("news", "post_minutes", default=15)),
        )
        if (
            cfg.get("news", "strict_news", default=True)
            and not calendar.last_fetch_ok
            and not calendar._cache
        ):
            news_blocked, news_reason = True, "calendar_unavailable_fail_closed"

    usd_sent = sentiment.score_texts(
        [
            "Federal Reserve monetary policy outlook interest rates inflation employment bitcoin risk",
        ]
    ).score
    usd_sent = max(-1.0, min(1.0, usd_sent + 0.25 * calendar.deviation_score(["USD"])))

    decision = fuse_signal(
        symbol=symbol,
        side=candidate.signal,
        model_prob=candidate.confidence,
        min_prob=cfg.min_probability,
        news_blocked=news_blocked,
        news_block_reason=news_reason,
        monthly_halted=breaker.halted,
        has_open_position=mt5c.has_open_positions(),
        mtf_aligned=candidate.mtf.aligned,
        mtf_reasons=candidate.mtf.reasons,
        usd_sentiment=usd_sent,
        confidence=confidence,
        tech_weight=float(cfg.get("fusion", "tech_weight", default=0.6)),
        news_weight=float(cfg.get("fusion", "news_weight", default=0.4)),
        sentiment_engine=sentiment,
    )

    if decision.signal not in ("BUY", "SELL"):
        logger.info(
            "[%s] WAIT bias=%s prob=%.3f fusion=%s mtf=%s",
            symbol,
            candidate.bias,
            candidate.confidence,
            decision.reason,
            candidate.reason,
        )
        return False

    levels = build_trade_levels(
        symbol=symbol,
        side=decision.signal,
        entry=candidate.entry,
        raw_sl=candidate.raw_sl,
        rr=cfg.rr,
        volume=cfg.lot_volume,
        max_risk_usd=cfg.max_risk_usd,
        sl_caps=cfg.get("risk", "per_symbol_sl_caps", default={}),
    )
    if not levels.ok:
        logger.info("[%s] risk reject: %s (risk=$%.2f)", symbol, levels.reason, levels.risk_usd)
        return False

    result = mt5c.order_send(
        symbol, decision.signal, levels.volume, candidate.entry, levels.sl, levels.tp
    )
    import MetaTrader5 as mt5

    if result is not None and result.retcode == mt5.TRADE_RETCODE_DONE:
        _record_experience(
            experience, symbol, decision, candidate, levels, feat_row, bundle, result.order
        )
        return True
    return False


def main() -> None:
    cfg = load_config()
    if cfg.mode != "demo":
        raise SystemExit("Refusing to run: mode must be demo for this build.")

    mt5c = MT5Connector(cfg)
    if not mt5c.connect():
        raise SystemExit("MT5 connection failed")

    runner = ModelRunner(cfg.resolve_path("paths", "models"))
    runner.load_all(cfg.symbols)

    confidence = ConfidenceStore(
        path=ROOT / cfg.get("learning", "state_path", default="models/confidence_state.json"),
        symbols=cfg.symbols,
        alpha=float(cfg.get("learning", "alpha", default=0.1)),
        w_min=float(cfg.get("learning", "w_min", default=0.3)),
        w_max=float(cfg.get("learning", "w_max", default=2.0)),
    )
    experience = ExperienceBuffer(cfg.resolve_path("paths", "experience"))
    calendar = ForexFactoryCalendar()
    sentiment = SentimentEngine(
        cache_minutes=int(cfg.get("news", "sentiment_cache_minutes", default=60))
    )
    breaker = MonthlyCircuitBreaker(
        max_dd_pct=float(cfg.get("risk", "monthly_max_dd_pct", default=10.0))
    )

    logger.info(
        "24/7 Sniper Engine | weekday=%s | weekend=%s | lot=%.2f | max_risk=$%.2f",
        cfg.weekday_symbols,
        cfg.weekend_symbols,
        cfg.lot_volume,
        cfg.max_risk_usd,
    )

    last_mode: str | None = None
    try:
        while True:
            try:
                if not mt5c.ensure():
                    time.sleep(cfg.scan_seconds)
                    continue

                active = cfg.active_symbols()
                mode = "weekend" if active == cfg.weekend_symbols else "weekday"
                if mode != last_mode:
                    logger.info("Mode=%s scanning %s", mode, active)
                    last_mode = mode

                equity = mt5c.account_equity()
                if breaker.update(equity):
                    logger.warning("Monthly circuit breaker ACTIVE (equity=%.2f)", equity)

                manage_positions(mt5c, cfg, confidence)

                if not mt5c.has_open_positions() and not breaker.halted:
                    for symbol in active:
                        placed = scan_symbol(
                            symbol,
                            mt5c,
                            runner,
                            cfg,
                            calendar,
                            sentiment,
                            confidence,
                            breaker,
                            experience,
                        )
                        if placed:
                            break
                else:
                    logger.debug(
                        "Skip entries: open_pos=%s halted=%s",
                        mt5c.has_open_positions(),
                        breaker.halted,
                    )

            except Exception as exc:  # noqa: BLE001
                logger.exception("Loop error: %s", exc)
                mt5c.connected = False

            time.sleep(cfg.scan_seconds)
    except KeyboardInterrupt:
        logger.info("Stopped by user")
    finally:
        mt5c.shutdown()


if __name__ == "__main__":
    main()
