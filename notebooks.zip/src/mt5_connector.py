"""MetaTrader5 connection helpers."""

from __future__ import annotations

import logging
from typing import Any

import MetaTrader5 as mt5
import pandas as pd

from .config import Config

logger = logging.getLogger(__name__)

TF_MAP = {
    "M1": mt5.TIMEFRAME_M1,
    "M5": mt5.TIMEFRAME_M5,
    "M15": mt5.TIMEFRAME_M15,
    "H1": mt5.TIMEFRAME_H1,
    "H4": mt5.TIMEFRAME_H4,
    "D1": mt5.TIMEFRAME_D1,
}


class MT5Connector:
    def __init__(self, config: Config) -> None:
        self.config = config
        self.connected = False

    def connect(self) -> bool:
        mt5_cfg = self.config.get("mt5") or {}
        kwargs: dict[str, Any] = {}
        if mt5_cfg.get("path"):
            kwargs["path"] = mt5_cfg["path"]
        if mt5_cfg.get("login"):
            kwargs["login"] = int(mt5_cfg["login"])
        if mt5_cfg.get("password"):
            kwargs["password"] = mt5_cfg["password"]
        if mt5_cfg.get("server"):
            kwargs["server"] = mt5_cfg["server"]

        ok = mt5.initialize(**kwargs) if kwargs else mt5.initialize()
        if not ok:
            logger.error("MT5 initialize failed: %s", mt5.last_error())
            self.connected = False
            return False

        acc = mt5.account_info()
        if acc is None:
            logger.error("No account_info: %s", mt5.last_error())
            self.connected = False
            return False

        if self.config.mode == "demo" and acc.trade_mode == mt5.ACCOUNT_TRADE_MODE_REAL:
            logger.error("Demo mode required but account is REAL. Abort.")
            mt5.shutdown()
            self.connected = False
            return False

        self.connected = True
        logger.info(
            "MT5 connected: login=%s server=%s balance=%.2f leverage=1:%s",
            acc.login,
            acc.server,
            acc.balance,
            acc.leverage,
        )
        return True

    def ensure(self) -> bool:
        if self.connected and mt5.terminal_info() is not None:
            return True
        logger.warning("MT5 reconnecting...")
        try:
            mt5.shutdown()
        except Exception:  # noqa: BLE001
            pass
        return self.connect()

    def shutdown(self) -> None:
        mt5.shutdown()
        self.connected = False

    def copy_rates(self, symbol: str, timeframe: str, count: int) -> pd.DataFrame:
        if not self.ensure():
            return pd.DataFrame()
        if not mt5.symbol_select(symbol, True):
            logger.warning("symbol_select failed for %s", symbol)
        tf = TF_MAP[timeframe]
        rates = mt5.copy_rates_from_pos(symbol, tf, 0, count)
        if rates is None:
            logger.warning("copy_rates failed %s %s: %s", symbol, timeframe, mt5.last_error())
            return pd.DataFrame()
        df = pd.DataFrame(rates)
        df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
        return df

    def positions(self, magic_only: bool = False) -> tuple:
        if not self.ensure():
            return ()
        positions = mt5.positions_get()
        if positions is None:
            return ()
        if magic_only:
            magic = self.config.magic
            return tuple(p for p in positions if p.magic == magic)
        return tuple(positions)

    def has_open_positions(self) -> bool:
        count_all = bool(self.config.get("position_guard", "count_all_positions", default=True))
        positions = self.positions(magic_only=not count_all)
        max_open = int(self.config.get("position_guard", "max_total_open", default=1))
        return len(positions) >= max_open

    def account_equity(self) -> float:
        if not self.ensure():
            return 0.0
        acc = mt5.account_info()
        return float(acc.equity) if acc else 0.0

    def order_send(
        self,
        symbol: str,
        side: str,
        volume: float,
        price: float,
        sl: float,
        tp: float,
    ) -> Any:
        if not self.ensure():
            return None
        info = mt5.symbol_info(symbol)
        tick = mt5.symbol_info_tick(symbol)
        if info is None or tick is None:
            logger.error("Missing symbol info/tick for %s", symbol)
            return None

        order_type = mt5.ORDER_TYPE_BUY if side == "BUY" else mt5.ORDER_TYPE_SELL
        price = float(tick.ask if side == "BUY" else tick.bid)
        filling = info.filling_mode
        # Prefer IOC then FOK then RETURN
        type_filling = mt5.ORDER_FILLING_IOC
        if filling & 2:
            type_filling = mt5.ORDER_FILLING_IOC
        elif filling & 1:
            type_filling = mt5.ORDER_FILLING_FOK
        else:
            type_filling = mt5.ORDER_FILLING_RETURN

        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": symbol,
            "volume": float(volume),
            "type": order_type,
            "price": price,
            "sl": float(sl),
            "tp": float(tp),
            "deviation": int(
                self.config.order_deviation(symbol)
                if hasattr(self.config, "order_deviation")
                else self.config.get("mt5", "deviation", default=20)
            ),
            "magic": self.config.magic,
            "comment": (
                "Weekend Sniper Bot"
                if symbol.upper() == "BTCUSD"
                else self.config.get("order_comment", default="Sniper $100 Bot")
            ),
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": type_filling,
        }
        result = mt5.order_send(request)
        if result is None:
            logger.error("order_send None: %s", mt5.last_error())
            return None
        if result.retcode != mt5.TRADE_RETCODE_DONE:
            logger.error("order_send failed: retcode=%s comment=%s", result.retcode, result.comment)
        else:
            logger.info(
                "Executed %s %s vol=%.2f sl=%s tp=%s ticket=%s",
                side,
                symbol,
                volume,
                sl,
                tp,
                result.order,
            )
        return result

    def modify_sltp(self, request: dict[str, Any]) -> Any:
        if not self.ensure():
            return None
        return mt5.order_send(request)
